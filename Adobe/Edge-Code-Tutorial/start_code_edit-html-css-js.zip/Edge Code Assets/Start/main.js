function doStuff(e) {
    return false;
}