function doStuff(e) {
    console.log("link clicked");
    return false;
}